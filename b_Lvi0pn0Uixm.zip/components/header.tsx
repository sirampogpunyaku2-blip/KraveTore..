"use client"

import { Store, MessageCircle } from "lucide-react"
import { Button } from "@/components/ui/button"

const WHATSAPP_NUMBER = "6285141319609"

export function Header() {
  const handleContact = () => {
    const message = encodeURIComponent("Halo min, saya mau tanya-tanya tentang produk premium")
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${message}`, "_blank")
  }

  return (
    <header className="sticky top-0 z-50 glass border-b border-border">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
            <Store className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-foreground tracking-tight">
              Krave<span className="text-primary">Tore</span>
            </h1>
            <p className="text-[10px] text-muted-foreground -mt-0.5">
              Premium Digital Store
            </p>
          </div>
        </div>

        <Button 
          onClick={handleContact}
          size="sm"
          className="bg-green-600 hover:bg-green-700 text-white gap-2"
        >
          <MessageCircle className="w-4 h-4" />
          <span className="hidden sm:inline">Hubungi Kami</span>
        </Button>
      </div>
    </header>
  )
}
