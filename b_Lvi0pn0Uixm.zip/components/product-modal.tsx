"use client"

import { useState } from "react"
import Image from "next/image"
import { Product, ProductOption } from "@/lib/products"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { AlertTriangle, MessageCircle, Check } from "lucide-react"

interface ProductModalProps {
  product: Product | null
  isOpen: boolean
  onClose: () => void
}

const WHATSAPP_NUMBER = "6285141319609"

export function ProductModal({ product, isOpen, onClose }: ProductModalProps) {
  const [selectedOption, setSelectedOption] = useState<ProductOption | null>(null)

  if (!product) return null

  const handleOrder = (option: ProductOption) => {
    const message = encodeURIComponent(
      `Min, Mau Order ${product.name} - ${option.name} (${option.price})`
    )
    const whatsappUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${message}`
    window.open(whatsappUrl, "_blank")
  }

  const handleClose = () => {
    setSelectedOption(null)
    onClose()
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="glass max-w-lg max-h-[90vh] overflow-y-auto border-border">
        <DialogHeader>
          <div className="flex items-center gap-3">
            <div className="relative w-14 h-14 rounded-xl overflow-hidden bg-white/10 flex-shrink-0">
              <Image
                src={product.image}
                alt={product.name}
                fill
                className="object-contain p-1"
                unoptimized
              />
            </div>
            <div>
              <DialogTitle className="text-xl font-bold text-foreground">
                {product.name}
              </DialogTitle>
              <Badge variant="secondary" className="mt-1">
                {product.category}
              </Badge>
            </div>
          </div>
        </DialogHeader>

        <div className="space-y-4 mt-4">
          {/* Options List */}
          <div>
            <h4 className="text-sm font-semibold text-muted-foreground mb-3">
              Pilih Paket Premium:
            </h4>
            <div className="space-y-2">
              {product.options.map((option, index) => (
                <div
                  key={index}
                  className={`flex items-center justify-between p-3 rounded-lg border transition-all cursor-pointer ${
                    selectedOption?.name === option.name
                      ? "border-primary bg-primary/10"
                      : "border-border hover:border-primary/50 hover:bg-secondary/50"
                  }`}
                  onClick={() => setSelectedOption(option)}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-colors ${
                      selectedOption?.name === option.name
                        ? "border-primary bg-primary"
                        : "border-muted-foreground"
                    }`}>
                      {selectedOption?.name === option.name && (
                        <Check className="w-3 h-3 text-primary-foreground" />
                      )}
                    </div>
                    <span className="text-sm font-medium text-foreground">
                      {option.name}
                    </span>
                  </div>
                  <span className="text-sm font-bold text-primary">
                    {option.price}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Order Button */}
          {selectedOption && (
            <Button
              onClick={() => handleOrder(selectedOption)}
              className="w-full bg-green-600 hover:bg-green-700 text-white gap-2"
            >
              <MessageCircle className="w-4 h-4" />
              Order via WhatsApp
            </Button>
          )}

          {/* Notes Section */}
          <div className="border-t border-border pt-4">
            <div className="flex items-center gap-2 mb-3">
              <AlertTriangle className="w-4 h-4 text-destructive" />
              <h4 className="text-sm font-bold text-destructive">NOTE</h4>
            </div>
            <ul className="space-y-2">
              {product.notes.map((note, index) => (
                <li 
                  key={index} 
                  className="text-sm text-destructive/90 flex items-start gap-2"
                >
                  <span className="font-mono text-xs bg-destructive/20 px-1.5 py-0.5 rounded">
                    0{index + 1}
                  </span>
                  <span>{note}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
