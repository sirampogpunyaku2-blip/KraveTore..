"use client"

import Image from "next/image"
import { Product } from "@/lib/products"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"

interface ProductCardProps {
  product: Product
  onSelect: (product: Product) => void
}

export function ProductCard({ product, onSelect }: ProductCardProps) {
  const lowestPrice = Math.min(...product.options.map(o => o.priceNum))
  
  return (
    <Card 
      className="glass group cursor-pointer transition-all duration-300 hover:scale-[1.02] hover:glow-primary overflow-hidden"
      onClick={() => onSelect(product)}
    >
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="relative w-12 h-12 rounded-xl overflow-hidden bg-white/10 flex-shrink-0">
              <Image
                src={product.image}
                alt={product.name}
                fill
                className="object-contain p-1"
                unoptimized
              />
            </div>
            <div>
              <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors">
                {product.name}
              </h3>
              <Badge variant="secondary" className="text-xs mt-1">
                {product.category}
              </Badge>
            </div>
          </div>
          <div className="text-right">
            <p className="text-xs text-muted-foreground">Mulai dari</p>
            <p className="text-sm font-bold text-primary">
              Rp {lowestPrice.toLocaleString('id-ID')}
            </p>
          </div>
        </div>
        
        <div className="mt-3 flex items-center justify-between">
          <p className="text-xs text-muted-foreground">
            {product.options.length} pilihan tersedia
          </p>
          <Button 
            size="sm" 
            variant="secondary"
            className="text-xs opacity-0 group-hover:opacity-100 transition-opacity"
          >
            Lihat Detail
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
