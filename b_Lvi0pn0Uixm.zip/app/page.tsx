"use client"

import { useState, useMemo } from "react"
import { products, Product } from "@/lib/products"
import { Header } from "@/components/header"
import { SearchBar } from "@/components/search-bar"
import { CategoryFilter } from "@/components/category-filter"
import { ProductCard } from "@/components/product-card"
import { ProductModal } from "@/components/product-modal"
import { Badge } from "@/components/ui/badge"
import { Sparkles, Shield, Zap, HeartHandshake } from "lucide-react"

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)

  const filteredProducts = useMemo(() => {
    return products.filter((product) => {
      const matchesSearch = product.name
        .toLowerCase()
        .includes(searchQuery.toLowerCase())
      const matchesCategory =
        selectedCategory === "all" || product.category === selectedCategory
      return matchesSearch && matchesCategory
    })
  }, [searchQuery, selectedCategory])

  const handleSelectProduct = (product: Product) => {
    setSelectedProduct(product)
    setIsModalOpen(true)
  }

  const handleCloseModal = () => {
    setIsModalOpen(false)
    setSelectedProduct(null)
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* Hero Section */}
      <section className="relative overflow-hidden border-b border-border">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/10 via-background to-background" />
        <div className="container mx-auto px-4 py-12 relative">
          <div className="text-center max-w-2xl mx-auto">
            <Badge className="mb-4 bg-primary/20 text-primary border-primary/30">
              <Sparkles className="w-3 h-3 mr-1" />
              Trusted Premium Store
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-3 text-balance">
              Akun Premium <span className="text-primary glow-text">Termurah</span> &amp; Terpercaya
            </h2>
            <p className="text-muted-foreground text-sm md:text-base text-pretty">
              Dapatkan akses ke berbagai layanan premium favorit dengan harga terjangkau. 
              Netflix, Spotify, Canva, dan masih banyak lagi!
            </p>
          </div>

          {/* Features */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-8 max-w-3xl mx-auto">
            {[
              { icon: Shield, label: "100% Aman", desc: "Garansi Terjamin" },
              { icon: Zap, label: "Fast Response", desc: "24/7 Support" },
              { icon: HeartHandshake, label: "Terpercaya", desc: "Banyak Testimoni" },
              { icon: Sparkles, label: "Harga Murah", desc: "Best Price" },
            ].map((feature, index) => (
              <div
                key={index}
                className="glass rounded-lg p-3 text-center"
              >
                <feature.icon className="w-5 h-5 text-primary mx-auto mb-1" />
                <p className="text-xs font-semibold text-foreground">{feature.label}</p>
                <p className="text-[10px] text-muted-foreground">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6">
        {/* Search & Filter */}
        <div className="space-y-4 mb-6">
          <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
            <SearchBar value={searchQuery} onChange={setSearchQuery} />
            <p className="text-sm text-muted-foreground">
              {filteredProducts.length} produk ditemukan
            </p>
          </div>
          <CategoryFilter
            selected={selectedCategory}
            onChange={setSelectedCategory}
          />
        </div>

        {/* Products Grid */}
        {filteredProducts.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onSelect={handleSelectProduct}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <p className="text-4xl mb-4">🔍</p>
            <h3 className="text-lg font-semibold text-foreground mb-2">
              Produk tidak ditemukan
            </h3>
            <p className="text-sm text-muted-foreground">
              Coba gunakan kata kunci lain atau pilih kategori yang berbeda
            </p>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-border mt-12">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center">
            <h3 className="text-lg font-bold text-foreground mb-1">
              Krave<span className="text-primary">Tore</span>
            </h3>
            <p className="text-sm text-muted-foreground mb-4">
              Premium Digital Store - Murah &amp; Terpercaya
            </p>
            <p className="text-xs text-muted-foreground">
              &copy; {new Date().getFullYear()} KraveTore. All rights reserved.
            </p>
          </div>
        </div>
      </footer>

      {/* Product Modal */}
      <ProductModal
        product={selectedProduct}
        isOpen={isModalOpen}
        onClose={handleCloseModal}
      />
    </div>
  )
}
