export interface ProductOption {
  name: string
  price: string
  priceNum: number
}

export interface Product {
  id: string
  name: string
  image: string
  category: string
  options: ProductOption[]
  notes: string[]
}

export const products: Product[] = [
  {
    id: "zoom",
    name: "Zoom",
    image: "https://logo.clearbit.com/zoom.us",
    category: "Meeting",
    options: [
      { name: "14 Hari", price: "Rp 5.000", priceNum: 5000 },
      { name: "1 Bulan", price: "Rp 11.500", priceNum: 11500 },
    ],
    notes: [
      "Tanyakan stock sebelum order.",
      "No rush.",
      "Beli harus sabar.",
      "No reff."
    ]
  },
  {
    id: "iqiyi",
    name: "iQIYI",
    image: "https://logo.clearbit.com/iqiyi.com",
    category: "Streaming",
    options: [
      { name: "Share Basic", price: "Rp 5.500", priceNum: 5500 },
      { name: "Share Standar", price: "Rp 6.500", priceNum: 6500 },
      { name: "Share Premium", price: "Rp 7.800", priceNum: 7800 },
      { name: "Private Standar", price: "Rp 17.000", priceNum: 17000 },
      { name: "Private Premium", price: "Rp 26.000", priceNum: 26000 },
    ],
    notes: [
      "Tanyakan stock sebelum order.",
      "No rush.",
      "Beli harus sabar.",
      "No reff."
    ]
  },
  {
    id: "reelshort",
    name: "ReelShort",
    image: "https://play-lh.googleusercontent.com/Fp-0x0pLzJ0z3JWKY-GqJuWIXmBKmVJKxnLK7cJyH8QnQN5HQmKn4nZx2kd4Y1qGQQ",
    category: "Streaming",
    options: [
      { name: "1 Bulan Share", price: "Rp 10.000", priceNum: 10000 },
    ],
    notes: [
      "Tanyakan stock sebelum order.",
      "No rush.",
      "Beli harus sabar.",
      "No reff."
    ]
  },
  {
    id: "loklok",
    name: "Loklok",
    image: "https://play-lh.googleusercontent.com/OuvPK2SP_QrqRKQE3K9hTP__vSJKMwfRzjb5Z9u5a6KR8h4K-D5w5C-n8X8HqCqhOA",
    category: "Streaming",
    options: [
      { name: "Basic Share 1 Bulan", price: "Rp 16.500", priceNum: 16500 },
      { name: "Standar Share 1 Bulan", price: "Rp 20.000", priceNum: 20000 },
    ],
    notes: [
      "Tanyakan stock sebelum order.",
      "Durasi lain tanyakan.",
      "Gar sesuai S&K, langgar: denda 500k+.",
      "No reff."
    ]
  },
  {
    id: "prime",
    name: "Prime Video",
    image: "https://logo.clearbit.com/primevideo.com",
    category: "Streaming",
    options: [
      { name: "1 Bulan Sharing", price: "Rp 6.500", priceNum: 6500 },
      { name: "1 Bulan Private", price: "Rp 11.000", priceNum: 11000 },
    ],
    notes: [
      "Langsung pay aja klo mau.",
      "Stock selalu ready.",
      "Beli harus sabar.",
      "No reff."
    ]
  },
  {
    id: "telegram",
    name: "Telegram",
    image: "https://logo.clearbit.com/telegram.org",
    category: "Social",
    options: [
      { name: "Premium 1 Bulan", price: "Rp 58.000", priceNum: 58000 },
      { name: "Star 50", price: "Rp 22.500", priceNum: 22500 },
      { name: "Star 75", price: "Rp 31.000", priceNum: 31000 },
      { name: "Star 100", price: "Rp 38.500", priceNum: 38500 },
      { name: "Star 150", price: "Rp 53.000", priceNum: 53000 },
      { name: "Star 200", price: "Rp 63.000", priceNum: 63000 },
      { name: "Star 250", price: "Rp 79.999", priceNum: 79999 },
      { name: "Star 350", price: "Rp 104.000", priceNum: 104000 },
      { name: "Star 750", price: "Rp 212.000", priceNum: 212000 },
      { name: "Star 1000", price: "Rp 280.500", priceNum: 280500 },
    ],
    notes: [
      "Tanyakan stock sebelum order.",
      "Fullgar ikut S&K.",
      "Beli harus sabar.",
      "No reff."
    ]
  },
  {
    id: "viu",
    name: "VIU",
    image: "https://logo.clearbit.com/viu.com",
    category: "Streaming",
    options: [
      { name: "1 Tahun", price: "Rp 1.500", priceNum: 1500 },
      { name: "Lifetime", price: "Rp 1.800", priceNum: 1800 },
      { name: "Private 5 Bulan", price: "Rp 1.800", priceNum: 1800 },
      { name: "Private 7 Bulan", price: "Rp 2.000", priceNum: 2000 },
      { name: "Private 8 Bulan", price: "Rp 2.300", priceNum: 2300 },
      { name: "Private 4 Bulan", price: "Rp 1.000", priceNum: 1000 },
    ],
    notes: [
      "Tanyakan stock sebelum order.",
      "No rush.",
      "Beli harus sabar.",
      "No reff."
    ]
  },
  {
    id: "meitu",
    name: "Meitu",
    image: "https://logo.clearbit.com/meitu.com",
    category: "Editing",
    options: [
      { name: "Premium 7 Hari (Acc B)", price: "Rp 1.500", priceNum: 1500 },
    ],
    notes: [
      "Tanyakan stock sebelum order.",
      "Acc seller wajib sabar.",
      "Durasi lain? Tanyakan.",
      "No reff."
    ]
  },
  {
    id: "hbomax",
    name: "HBO Max",
    image: "https://logo.clearbit.com/hbomax.com",
    category: "Streaming",
    options: [
      { name: "1 Bulan Share", price: "Rp 12.000", priceNum: 12000 },
      { name: "1 Bulan Private", price: "Rp 25.000", priceNum: 25000 },
    ],
    notes: [
      "Tanyakan stock sebelum order.",
      "No rush.",
      "Beli harus sabar.",
      "No reff."
    ]
  },
  {
    id: "chatgpt",
    name: "ChatGPT",
    image: "https://logo.clearbit.com/openai.com",
    category: "AI",
    options: [
      { name: "Head 1 Bulan No Gar", price: "Rp 10.000", priceNum: 10000 },
      { name: "GPT Plus Share 1 Bulan Gar 20d", price: "Rp 8.000", priceNum: 8000 },
      { name: "GPT Plus 1 Bulan No Gar Private", price: "Rp 9.000", priceNum: 9000 },
    ],
    notes: [
      "Tanyakan stock sebelum order.",
      "Head bisa invite 5, disarankan max 4.",
      "No gar bukan berarti tidak awet (tergantung pemakaian).",
      "No reff."
    ]
  },
  {
    id: "ibispaint",
    name: "Ibis Paint",
    image: "https://play-lh.googleusercontent.com/gQzKYP8aVJ-Cp6BgJv5v3XJnJtSrv-gV9BKvO2sAOzXOQ8H_5qCQJFMGm0FcYmqQhA",
    category: "Editing",
    options: [
      { name: "7 Hari", price: "Rp 1.500", priceNum: 1500 },
      { name: "1 Bulan", price: "Rp 2.000", priceNum: 2000 },
    ],
    notes: [
      "Tanyakan stock sebelum order.",
      "Via invite.",
      "Beli harus sabar.",
      "No reff."
    ]
  },
  {
    id: "canva",
    name: "Canva",
    image: "https://logo.clearbit.com/canva.com",
    category: "Design",
    options: [
      { name: "Member 1 Bulan", price: "Rp 1.500", priceNum: 1500 },
      { name: "Member 1 Tahun", price: "Rp 2.500", priceNum: 2500 },
      { name: "Lifetime Member", price: "Rp 2.400", priceNum: 2400 },
      { name: "Design 1 Bulan", price: "Rp 1.800", priceNum: 1800 },
      { name: "Design 1 Tahun", price: "Rp 2.800", priceNum: 2800 },
      { name: "Lifetime Design", price: "Rp 1.800", priceNum: 1800 },
      { name: "Admin 1 Bulan", price: "Rp 2.800", priceNum: 2800 },
      { name: "Admin 1 Tahun", price: "Rp 3.800", priceNum: 3800 },
      { name: "Lifetime Admin", price: "Rp 2.800", priceNum: 2800 },
      { name: "Owner/Head (Acc S Fullgar)", price: "Rp 5.000", priceNum: 5000 },
    ],
    notes: [
      "Tanyakan stock sebelum order.",
      "Admin inv 50 member.",
      "Head inv 100 member.",
      "No reff."
    ]
  },
  {
    id: "capcut",
    name: "CapCut",
    image: "https://logo.clearbit.com/capcut.com",
    category: "Editing",
    options: [
      { name: "7 Hari Private", price: "Rp 1.800", priceNum: 1800 },
      { name: "14 Hari Private", price: "Rp 2.500", priceNum: 2500 },
      { name: "21 Hari Private", price: "Rp 2.800", priceNum: 2800 },
      { name: "28 Hari Private", price: "Rp 3.500", priceNum: 3500 },
      { name: "35 Hari Private", price: "Rp 3.800", priceNum: 3800 },
      { name: "45 Hari Private", price: "Rp 4.800", priceNum: 4800 },
    ],
    notes: [
      "Tanyakan stock sebelum order.",
      "Transaksi only grup.",
      "Beli harus sabar.",
      "No reff."
    ]
  },
  {
    id: "wink",
    name: "Wink",
    image: "https://play-lh.googleusercontent.com/8K8-P4wN_BNqfZJ8GQHPwcI2KlFgYRJ7SqvH6dKo6I9SVGwQ3XJGzHf_vvCy3cJc0A",
    category: "Editing",
    options: [
      { name: "Acc B 7 Hari", price: "Rp 1.500", priceNum: 1500 },
      { name: "Acc S 7 Hari", price: "Rp 2.000", priceNum: 2000 },
      { name: "Acc B 1 Bulan", price: "Rp 2.500", priceNum: 2500 },
    ],
    notes: [
      "Tanyakan stock sebelum order.",
      "No rush.",
      "Beli harus sabar.",
      "No reff."
    ]
  },
  {
    id: "spotify",
    name: "Spotify",
    image: "https://logo.clearbit.com/spotify.com",
    category: "Music",
    options: [
      { name: "1 Bulan Family Plan Fullgar", price: "Rp 17.000", priceNum: 17000 },
      { name: "1 Bulan Individual Fullgar", price: "Rp 16.700", priceNum: 16700 },
      { name: "2 Bulan Individual Fullgar", price: "Rp 24.000", priceNum: 24000 },
      { name: "3 Bulan Individual Fullgar", price: "Rp 36.000", priceNum: 36000 },
      { name: "Individual 1 Bulan Gar 7d", price: "Rp 10.000", priceNum: 10000 },
      { name: "Individual 1 Bulan Gar 24jam", price: "Rp 8.000", priceNum: 8000 },
      { name: "Individual 3 Bulan Gar 24jam", price: "Rp 11.000", priceNum: 11000 },
      { name: "Fam Head 1 Bulan", price: "Rp 34.800", priceNum: 34800 },
      { name: "Fam Head 2 Bulan", price: "Rp 54.600", priceNum: 54600 },
    ],
    notes: [
      "Fast process, tanyakan stock sebelum order.",
      "Spotify famplan req pw sendiri +15k.",
      "Bisa Android & iOS, semua acc seller.",
      "No reff."
    ]
  },
  {
    id: "wetv",
    name: "WeTV",
    image: "https://logo.clearbit.com/wetv.vip",
    category: "Streaming",
    options: [
      { name: "Sharing 1 Bulan", price: "Rp 8.500", priceNum: 8500 },
      { name: "Private 1 Bulan", price: "Rp 27.000", priceNum: 27000 },
    ],
    notes: [
      "Tanyakan stock sebelum order.",
      "Sharing 6 orang.",
      "Beli harus sabar.",
      "No reff."
    ]
  },
  {
    id: "melolo",
    name: "Melolo",
    image: "https://play-lh.googleusercontent.com/GxFdgQ1QH4cNBVxTJBqQ9JqLgKmBKHQ5_l8g9KHVFX9GhZ4kCQJqKEa0qGJqSQVpJQ",
    category: "Reading",
    options: [
      { name: "1 Bulan", price: "Rp 5.000", priceNum: 5000 },
      { name: "Lifetime", price: "Rp 8.000", priceNum: 8000 },
    ],
    notes: [
      "Tanyakan stock sebelum order.",
      "No rush.",
      "Beli harus sabar.",
      "No reff."
    ]
  },
  {
    id: "netflix",
    name: "Netflix",
    image: "https://logo.clearbit.com/netflix.com",
    category: "Streaming",
    options: [
      { name: "1P1U 1 Bulan", price: "Rp 19.500", priceNum: 19500 },
      { name: "1P2U 1 Bulan", price: "Rp 15.500", priceNum: 15500 },
      { name: "Semi 1 Bulan", price: "Rp 22.000", priceNum: 22000 },
      { name: "1P1U 7 Hari", price: "Rp 10.000", priceNum: 10000 },
      { name: "1P2U 7 Hari", price: "Rp 8.500", priceNum: 8500 },
      { name: "Semi 7 Hari", price: "Rp 12.000", priceNum: 12000 },
    ],
    notes: [
      "Tanyakan stock sebelum order.",
      "1 bulan: 21-25 hari.",
      "Beli harus sabar.",
      "No reff."
    ]
  },
  {
    id: "alightmotion",
    name: "Alight Motion",
    image: "https://play-lh.googleusercontent.com/HbP-IpE8w-rX6u7vTMWVaJvNYK7IyMvL7T3EqGGMVPaVv4P-JjNqK9vxQj0E6G9qSA",
    category: "Editing",
    options: [
      { name: "3 Bulan", price: "Rp 1.400", priceNum: 1400 },
      { name: "9 Bulan", price: "Rp 1.600", priceNum: 1600 },
      { name: "1 Tahun", price: "Rp 2.000", priceNum: 2000 },
    ],
    notes: [
      "Beli banyak? Di bulk.",
      "Acc gene.",
      "Beli harus sabar.",
      "No reff."
    ]
  },
  {
    id: "bstation",
    name: "Bstation",
    image: "https://play-lh.googleusercontent.com/1LEtNXC4DrKJEQo7Y5Gz0CxyYJAVvMuF4v_yVPvt9TkKQyPnQaFgBMJXC9Bq5m7JaQ",
    category: "Streaming",
    options: [
      { name: "Share 1 Bulan", price: "Rp 6.800", priceNum: 6800 },
      { name: "Share 3 Bulan", price: "Rp 9.500", priceNum: 9500 },
      { name: "Share 1 Tahun", price: "Rp 14.500", priceNum: 14500 },
    ],
    notes: [
      "Tanyakan stock sebelum order.",
      "No rush order.",
      "Beli harus sabar.",
      "No reff."
    ]
  },
  {
    id: "disney",
    name: "Disney+",
    image: "https://logo.clearbit.com/disneyplus.com",
    category: "Streaming",
    options: [
      { name: "10U 1 Hari", price: "Rp 4.000", priceNum: 4000 },
      { name: "10U 2 Hari", price: "Rp 6.300", priceNum: 6300 },
      { name: "10U 5 Hari", price: "Rp 8.500", priceNum: 8500 },
      { name: "10U 7 Hari", price: "Rp 10.000", priceNum: 10000 },
      { name: "10U 1 Bulan", price: "Rp 16.500", priceNum: 16500 },
      { name: "10U 1 Tahun", price: "Rp 40.500", priceNum: 40500 },
    ],
    notes: [
      "Tanyakan stock sebelum order.",
      "Garansi BF only.",
      "Acc strong 10U.",
      "No reff (kecuali kesalahan admin)."
    ]
  },
  {
    id: "youtube",
    name: "YouTube Premium",
    image: "https://logo.clearbit.com/youtube.com",
    category: "Streaming",
    options: [
      { name: "Head Acc B Fresh", price: "Rp 2.450/bulan", priceNum: 2450 },
      { name: "Individual Acc B Fresh", price: "Rp 2.400/bulan", priceNum: 2400 },
      { name: "Head Acc B Old", price: "Rp 2.550/bulan", priceNum: 2550 },
      { name: "Individual Acc B Old", price: "Rp 2.500/bulan", priceNum: 2500 },
    ],
    notes: [
      "Acc old: belum pernah premium.",
      "Wajib kirim email & password yang benar.",
      "Sudah termasuk YouTube Music.",
      "Max 5x salah, lebih dari itu hangus."
    ]
  },
]

export const categories = [
  { id: "all", name: "Semua" },
  { id: "Streaming", name: "Streaming" },
  { id: "Music", name: "Music" },
  { id: "Design", name: "Design" },
  { id: "Editing", name: "Editing" },
  { id: "AI", name: "AI" },
  { id: "Social", name: "Social" },
  { id: "Meeting", name: "Meeting" },
  { id: "Reading", name: "Reading" },
]
